// -*- tab-width: 4 -*-
//Title:        JET
//Copyright:    2005
//Author:       Ralph Grishman
//Description:  A Java-based Information Extraction Toolkil
//              (ACE extensions)

package AceJet;

/**
 *  the value of an AceEvent argument:  either a AceEntity, AceValue, or AceTimex.
 */

abstract class AceEventArgumentValue {

	public String id;

}
