// -*- tab-width: 4 -*-
/**
 *
 */
package Jet.NE;

enum MatchType {
	NORMAL, NOT, ANY, SPECIAL
}
