// -*- tab-width: 4 -*-
package Jet.Format;

public class InvalidFormatException extends Exception {
	public InvalidFormatException(String message) {
		super(message);
	}

	public InvalidFormatException() {
	}
}
