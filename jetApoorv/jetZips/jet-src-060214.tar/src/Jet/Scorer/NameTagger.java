// -*- tab-width: 4 -*-
package Jet.Scorer;

import Jet.Tipster.*;

public interface NameTagger {

	public void tagDocument (Document doc);

}
