// -*- tab-width: 4 -*-
package Jet.NE;

/**
 * Type of BIO.
 *
 * @author Akira ODA
 */
public enum BioType {
	B, I, O
}
